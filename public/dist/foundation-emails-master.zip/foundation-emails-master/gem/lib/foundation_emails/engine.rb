require "rails"

module FoundationEmails
  class Engine < ::Rails::Engine
  end
end
