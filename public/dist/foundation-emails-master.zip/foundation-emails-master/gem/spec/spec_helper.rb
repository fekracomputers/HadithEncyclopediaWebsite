$LOAD_PATH.unshift File.expand_path("../../lib", __FILE__)
require "foundation_emails"
